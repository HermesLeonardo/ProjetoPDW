package br.edu.unifio.projetopdw;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoPdwApplicationTests {

    @Test
    void contextLoads() {
    }

}
