package br.edu.unifio.projetopdw;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoPdwApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProjetoPdwApplication.class, args);
    }

}

